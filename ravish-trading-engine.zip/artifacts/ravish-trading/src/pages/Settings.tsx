import { useEffect, useState } from "react";
import { useGetSettings, useUpdateSettings, getGetSettingsQueryKey, SettingsUpdateExecutionMode } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";

export default function SettingsPage() {
  const { data: settings, isLoading } = useGetSettings();
  const updateSettings = useUpdateSettings();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [local, setLocal] = useState({
    executionMode: "manual" as SettingsUpdateExecutionMode,
    maxRiskPerTrade: 1,
    maxPortfolioRisk: 10,
    profitTarget50: 50,
    stopLossMultiplier: 2,
    defaultDte: 45,
    shortDelta: 0.20,
    alpacaConnected: false,
    alpacaApiKey: "",
    scannerMode: "mock" as "mock" | "live",
    marketDataProvider: "mock" as "mock" | "alpaca" | "polygon",
    eventRiskEnabled: true,
    eventRiskBlockEarningsShortPremium: true,
    eventRiskAutoBlockHigh: true,
  });

  useEffect(() => {
    if (settings) {
      setLocal({
        executionMode: settings.executionMode,
        maxRiskPerTrade: settings.maxRiskPerTrade,
        maxPortfolioRisk: settings.maxPortfolioRisk,
        profitTarget50: settings.profitTarget50,
        stopLossMultiplier: settings.stopLossMultiplier,
        defaultDte: settings.defaultDte || 45,
        shortDelta: settings.shortDelta || 0.20,
        alpacaConnected: settings.alpacaConnected,
        alpacaApiKey: settings.alpacaApiKey || "",
        scannerMode: (settings.scannerMode as "mock" | "live") || "mock",
        marketDataProvider: (settings.marketDataProvider as "mock" | "alpaca" | "polygon") || "mock",
        eventRiskEnabled: settings.eventRiskEnabled ?? true,
        eventRiskBlockEarningsShortPremium: settings.eventRiskBlockEarningsShortPremium ?? true,
        eventRiskAutoBlockHigh: settings.eventRiskAutoBlockHigh ?? true,
      });
    }
  }, [settings]);

  const handleSave = () => {
    updateSettings.mutate(
      { 
        data: {
          executionMode: local.executionMode,
          maxRiskPerTrade: Number(local.maxRiskPerTrade),
          maxPortfolioRisk: Number(local.maxPortfolioRisk),
          profitTarget50: Number(local.profitTarget50),
          stopLossMultiplier: Number(local.stopLossMultiplier),
          defaultDte: Number(local.defaultDte),
          shortDelta: Number(local.shortDelta),
          alpacaApiKey: local.alpacaApiKey || undefined,
          scannerMode: local.scannerMode,
          marketDataProvider: local.marketDataProvider,
          eventRiskEnabled: local.eventRiskEnabled,
          eventRiskBlockEarningsShortPremium: local.eventRiskBlockEarningsShortPremium,
          eventRiskAutoBlockHigh: local.eventRiskAutoBlockHigh,
        }
      },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetSettingsQueryKey() });
          toast({ title: "Settings saved" });
        },
        onError: () => {
          toast({ title: "Failed to save settings", variant: "destructive" });
        }
      }
    );
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-[400px] w-full max-w-2xl" />
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-2xl">
      <h1 className="text-2xl font-bold text-foreground">System Settings</h1>

      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle>Execution Engine</CardTitle>
          <CardDescription>Configure how trades are executed based on scanner signals.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <label className="text-sm font-medium">Execution Mode</label>
            <Select value={local.executionMode} onValueChange={(v: any) => setLocal({...local, executionMode: v})}>
              <SelectTrigger className="bg-background">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="manual">Manual (Alert Only)</SelectItem>
                <SelectItem value="semi_auto">Semi-Auto (1-Click Approve)</SelectItem>
                <SelectItem value="full_auto">Full Auto (Unattended)</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground">Full Auto runs unattended — manage guardrails and the master kill switch on the AutoPilot page.</p>
          </div>

          <div className="pt-4 border-t border-border grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Max Risk Per Trade (%)</label>
              <Input 
                type="number" 
                value={local.maxRiskPerTrade} 
                onChange={e => setLocal({...local, maxRiskPerTrade: Number(e.target.value)})}
                className="bg-background font-mono"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Max Portfolio Risk (%)</label>
              <Input 
                type="number" 
                value={local.maxPortfolioRisk} 
                onChange={e => setLocal({...local, maxPortfolioRisk: Number(e.target.value)})}
                className="bg-background font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Profit Target (%)</label>
              <Input 
                type="number" 
                value={local.profitTarget50} 
                onChange={e => setLocal({...local, profitTarget50: Number(e.target.value)})}
                className="bg-background font-mono"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Stop Loss Multiplier (xCredit)</label>
              <Input 
                type="number" 
                value={local.stopLossMultiplier} 
                onChange={e => setLocal({...local, stopLossMultiplier: Number(e.target.value)})}
                className="bg-background font-mono"
              />
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Default DTE</label>
              <Input 
                type="number" 
                value={local.defaultDte} 
                onChange={e => setLocal({...local, defaultDte: Number(e.target.value)})}
                className="bg-background font-mono"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Short Delta Target</label>
              <Input 
                type="number" 
                step="0.01"
                value={local.shortDelta} 
                onChange={e => setLocal({...local, shortDelta: Number(e.target.value)})}
                className="bg-background font-mono"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle>Market Data</CardTitle>
          <CardDescription>Choose the scanner data source. Live mode pulls real option chains from the selected provider; without provider credentials it falls back to mock data.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Scanner Mode</label>
              <Select value={local.scannerMode} onValueChange={(v: any) => setLocal({...local, scannerMode: v})}>
                <SelectTrigger className="bg-background">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="mock">Mock (Simulated)</SelectItem>
                  <SelectItem value="live">Live (Provider Chains)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Data Provider</label>
              <Select value={local.marketDataProvider} onValueChange={(v: any) => setLocal({...local, marketDataProvider: v})}>
                <SelectTrigger className="bg-background">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="mock">Mock</SelectItem>
                  <SelectItem value="alpaca">Alpaca</SelectItem>
                  <SelectItem value="polygon">Polygon</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <p className="text-xs text-muted-foreground">Provider credentials are read from the broker connection or environment. Missing or stale data is automatically rejected and reported in the Market Data Health panel.</p>
        </CardContent>
      </Card>

      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle>Broker Connection</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-4 border border-border rounded-lg bg-background">
            <div>
              <div className="font-medium">Alpaca Paper API</div>
              <div className={`text-xs ${local.alpacaConnected ? 'text-success' : 'text-destructive'}`}>
                {local.alpacaConnected ? 'Connected & Active' : 'Not Connected'}
              </div>
            </div>
            <Switch checked={local.alpacaConnected} disabled />
          </div>
          
          <div className="space-y-2">
            <label className="text-sm font-medium">API Key</label>
            <Input 
              type="password"
              placeholder="PK..."
              value={local.alpacaApiKey} 
              onChange={e => setLocal({...local, alpacaApiKey: e.target.value})}
              className="bg-background font-mono"
            />
          </div>
        </CardContent>
      </Card>

      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle>Event Risk Filter</CardTitle>
          <CardDescription>Detect earnings, FOMC, CPI, jobs, dividends and other high-impact events. Lowers the Ravish Score in the trade window and enforces hard blocks server-side.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between p-4 border border-border rounded-lg bg-background">
            <div>
              <div className="font-medium">Enable Event Risk Filter</div>
              <div className="text-xs text-muted-foreground">Master switch — scores and warnings ignore events when off.</div>
            </div>
            <Switch
              checked={local.eventRiskEnabled}
              onCheckedChange={(c) => setLocal({ ...local, eventRiskEnabled: c })}
              data-testid="switch-event-risk-enabled"
            />
          </div>
          <div className="flex items-center justify-between p-4 border border-border rounded-lg bg-background">
            <div>
              <div className="font-medium">Block short premium before earnings</div>
              <div className="text-xs text-muted-foreground">Refuse iron condors / iron flys whose window contains an earnings event.</div>
            </div>
            <Switch
              checked={local.eventRiskBlockEarningsShortPremium}
              onCheckedChange={(c) => setLocal({ ...local, eventRiskBlockEarningsShortPremium: c })}
              disabled={!local.eventRiskEnabled}
              data-testid="switch-event-risk-block-earnings"
            />
          </div>
          <div className="flex items-center justify-between p-4 border border-border rounded-lg bg-background">
            <div>
              <div className="font-medium">Block AutoPilot on high event risk</div>
              <div className="text-xs text-muted-foreground">Halt unattended auto-execution when a candidate's window carries high event risk.</div>
            </div>
            <Switch
              checked={local.eventRiskAutoBlockHigh}
              onCheckedChange={(c) => setLocal({ ...local, eventRiskAutoBlockHigh: c })}
              disabled={!local.eventRiskEnabled}
              data-testid="switch-event-risk-auto-block"
            />
          </div>
        </CardContent>
      </Card>

      <Button 
        onClick={handleSave} 
        disabled={updateSettings.isPending}
        className="w-full bg-primary hover:bg-primary/90"
      >
        {updateSettings.isPending ? "Saving..." : "Save Settings"}
      </Button>
    </div>
  );
}
