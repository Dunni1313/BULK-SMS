import { Router, type IRouter } from "express";
import { db, settingsTable } from "@workspace/db";
import { GetSettingsResponse, UpdateSettingsResponse, UpdateSettingsBody } from "@workspace/api-zod";

const router: IRouter = Router();

async function getOrCreateSettings() {
  const existing = await db.select().from(settingsTable).limit(1);
  if (existing.length > 0) return existing[0];

  const [created] = await db
    .insert(settingsTable)
    .values({
      executionMode: "manual",
      maxRiskPerTrade: 1.0,
      maxPortfolioRisk: 10.0,
      profitTarget50: 50.0,
      profitTarget75: 75.0,
      profitTarget90: 90.0,
      stopLossMultiplier: 2.0,
      alpacaConnected: false,
      alpacaApiKey: null,
      defaultDte: 45,
      shortDelta: 0.20,
      minIvRank: 30.0,
    })
    .returning();

  return created;
}

router.get("/settings", async (_req, res): Promise<void> => {
  const settings = await getOrCreateSettings();
  res.json(GetSettingsResponse.parse(settings));
});

router.patch("/settings", async (req, res): Promise<void> => {
  const parsed = UpdateSettingsBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const existing = await getOrCreateSettings();

  const [updated] = await db
    .update(settingsTable)
    .set(parsed.data)
    .returning();

  res.json(UpdateSettingsResponse.parse(updated));
});

export default router;
