// AI Trading Coach — LLM narration layer.
//
// This is the "prose" half of the hybrid coach. It takes the deterministic facts
// produced by coach.ts and asks the model to narrate them in plain English. It
// NEVER computes its own numbers, and it NEVER advises placing a trade. If the
// model is unavailable (no key, network/error), it degrades gracefully to a
// deterministic template so every endpoint always returns a useful answer.
//
// Provider-agnostic: the OPENAI_API_KEY secret may hold either an OpenAI key
// (sk-...) or an Anthropic key (sk-ant-...). We detect the prefix and use the
// matching SDK so the coach works with whichever valid key the user supplied.

import OpenAI from "openai";
import Anthropic from "@anthropic-ai/sdk";
import { logger } from "./logger.js";
import {
  COACH_DISCLAIMER,
  type TradeExplanation,
  type GreekLesson,
} from "./coach.js";

const OPENAI_MODEL = process.env.OPENAI_COACH_MODEL || "gpt-4o-mini";
const ANTHROPIC_MODEL = process.env.ANTHROPIC_COACH_MODEL || "claude-haiku-4-5-20251001";

type Provider = "openai" | "anthropic" | null;

let provider: Provider = null;
let openaiClient: OpenAI | null = null;
let anthropicClient: Anthropic | null = null;
let initialized = false;

function init(): void {
  if (initialized) return;
  initialized = true;
  const key = process.env.OPENAI_API_KEY?.trim();
  if (!key) {
    provider = null;
    return;
  }
  if (key.startsWith("sk-ant-")) {
    provider = "anthropic";
    anthropicClient = new Anthropic({ apiKey: key });
  } else {
    provider = "openai";
    openaiClient = new OpenAI({ apiKey: key });
  }
}

export function llmAvailable(): boolean {
  init();
  return provider !== null;
}

// ─── Concurrency hardening ───────────────────────────────────────────────────
// Coach LLM calls take ~10-20s. Under concurrent load they used to pile up and
// surface as 502 gateway timeouts / blank cards. Three guards prevent that:
//   1. a hard per-call timeout that aborts a hung request so it degrades to the
//      deterministic template instead of hanging forever,
//   2. a short-lived cache keyed by the lesson/trade so repeat asks are instant,
//   3. single-flight dedup so N concurrent identical asks share ONE LLM call.

const LLM_TIMEOUT_MS = Number(process.env.COACH_LLM_TIMEOUT_MS) || 25_000;
const CACHE_MAX = 200;
const CACHE_TTL_MS = 10 * 60 * 1000;

interface CacheEntry {
  text: string;
  expires: number;
}

// Shared by both the streaming and non-streaming narration paths so a result
// produced by one serves the other.
const narrationCache = new Map<string, CacheEntry>();
// In-flight LLM calls keyed by cache key. Resolves with the final (disclaimer-
// enforced) text, or null if the LLM produced nothing usable.
const inflight = new Map<string, Promise<string | null>>();

function cacheGet(key: string): string | null {
  const e = narrationCache.get(key);
  if (!e) return null;
  if (Date.now() > e.expires) {
    narrationCache.delete(key);
    return null;
  }
  // Refresh recency for a simple LRU eviction order.
  narrationCache.delete(key);
  narrationCache.set(key, e);
  return e.text;
}

function cacheSet(key: string, text: string): void {
  narrationCache.set(key, { text, expires: Date.now() + CACHE_TTL_MS });
  while (narrationCache.size > CACHE_MAX) {
    const oldest = narrationCache.keys().next().value;
    if (oldest === undefined) break;
    narrationCache.delete(oldest);
  }
}

// Abort signal that fires after `ms`, with a cleanup to clear the timer once the
// call settles. Aborting makes the SDK throw, which our catch turns into a
// template fallback.
function withTimeout(ms: number): { signal: AbortSignal; done: () => void } {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), ms);
  return { signal: ctrl.signal, done: () => clearTimeout(timer) };
}

const SYSTEM_PROMPT = `You are the Ravish Trading Coach — a patient, rigorous options-trading TUTOR. Your job is to TEACH and EXPLAIN, never to advise.

Hard rules:
- You are an educator, not a broker or advisor. NEVER tell the user to buy, sell, place, submit, or execute a trade. NEVER say "you should take this trade".
- Use ONLY the numbers in the provided DATA. Do not invent or estimate any figure not present in the data.
- Explain the *why* behind the mechanics (POP, EV, the Greeks, max loss, assignment) in clear, plain English a motivated beginner can follow.
- Be concise and structured. Prefer short paragraphs or tight bullet points.
- The Ravish Engine never executes trades automatically; any order is a manual decision the user makes on the Trade Ticket. Reinforce this if execution comes up.`;

export type NarrationSource = "llm" | "template";

export interface Narration {
  text: string;
  source: NarrationSource;
}

// Optional explanation depth. Threaded into the prompt and the cache key so a
// beginner and an advanced ask for the same lesson don't share a cached answer.
export type CoachLevel = "beginner" | "advanced";

function levelInstruction(level?: CoachLevel): string {
  if (level === "beginner")
    return " Explain at a BEGINNER depth: assume little prior options knowledge, define any jargon you use, and keep it simple and encouraging.";
  if (level === "advanced")
    return " Explain at an ADVANCED depth: assume the reader already knows options basics; be concise, precise, and focus on the nuanced trade-offs.";
  return "";
}

function levelKey(level?: CoachLevel): string {
  return level ? `:${level}` : "";
}

// Callback that receives incremental text chunks as the model streams them.
export type TokenSink = (chunk: string) => void;

// Unified single-shot completion across providers. Returns null on any failure
// so callers fall back to their deterministic template.
async function complete(
  userContent: string,
  maxTokens: number,
  opts: { json?: boolean } = {},
): Promise<string | null> {
  init();
  const { signal, done } = withTimeout(LLM_TIMEOUT_MS);
  try {
    if (provider === "anthropic" && anthropicClient) {
      const sys = opts.json
        ? `${SYSTEM_PROMPT}\n\nRespond ONLY with a single valid JSON object, no prose or code fences.`
        : SYSTEM_PROMPT;
      const resp = await anthropicClient.messages.create(
        {
          model: ANTHROPIC_MODEL,
          max_tokens: maxTokens,
          system: sys,
          messages: [{ role: "user", content: userContent }],
        },
        { signal },
      );
      const block = resp.content.find((b) => b.type === "text");
      return block && block.type === "text" ? block.text.trim() : null;
    }
    if (provider === "openai" && openaiClient) {
      const resp = await openaiClient.chat.completions.create(
        {
          model: OPENAI_MODEL,
          max_completion_tokens: maxTokens,
          ...(opts.json ? { response_format: { type: "json_object" as const } } : {}),
          messages: [
            { role: "system", content: SYSTEM_PROMPT },
            { role: "user", content: userContent },
          ],
        },
        { signal },
      );
      return resp.choices[0]?.message?.content?.trim() ?? null;
    }
    return null;
  } catch (err) {
    logger.warn({ err, provider }, "coach LLM completion failed; using template fallback");
    return null;
  } finally {
    done();
  }
}

// Safety invariant: every narration must carry the coach disclaimer — on BOTH the
// LLM path AND the deterministic template/fallback path. The model is instructed to
// include it, but enforce it deterministically so neither an LLM response nor a
// template (which may carry only a feature-specific advisory like
// ADJUSTMENT_DISCLAIMER) can ever ship without the standard COACH_DISCLAIMER.
export function enforceDisclaimer(text: string): string {
  return text.includes(COACH_DISCLAIMER) ? text : `${text}\n\n${COACH_DISCLAIMER}`;
}

async function narrate(
  userPrompt: string,
  data: unknown,
  fallback: string,
  cacheKey?: string,
): Promise<Narration> {
  if (!llmAvailable()) return { text: enforceDisclaimer(fallback), source: "template" };
  if (cacheKey) {
    const cached = cacheGet(cacheKey);
    if (cached) return { text: cached, source: "llm" };
  }
  const content = `${userPrompt}\n\nDATA (authoritative — use these exact numbers, do not invent others):\n${JSON.stringify(data)}`;
  const run = async (): Promise<string | null> => {
    const text = await complete(content, 900);
    if (!text) return null;
    const withDisclaimer = enforceDisclaimer(text);
    if (cacheKey) cacheSet(cacheKey, withDisclaimer);
    return withDisclaimer;
  };
  // Single-flight: concurrent identical asks share one LLM call.
  let finalText: string | null;
  if (cacheKey) {
    let p = inflight.get(cacheKey);
    if (!p) {
      p = run();
      inflight.set(cacheKey, p);
      void p.finally(() => inflight.delete(cacheKey));
    }
    finalText = await p;
  } else {
    finalText = await run();
  }
  if (!finalText) return { text: enforceDisclaimer(fallback), source: "template" };
  return { text: finalText, source: "llm" };
}

// Streaming counterpart of complete(). Pushes text chunks through onToken as the
// model produces them and resolves with the full text, or null on any failure
// so callers fall back to their deterministic template.
async function completeStream(
  userContent: string,
  maxTokens: number,
  onToken: TokenSink,
): Promise<string | null> {
  init();
  const { signal, done } = withTimeout(LLM_TIMEOUT_MS);
  try {
    if (provider === "anthropic" && anthropicClient) {
      const stream = anthropicClient.messages.stream(
        {
          model: ANTHROPIC_MODEL,
          max_tokens: maxTokens,
          system: SYSTEM_PROMPT,
          messages: [{ role: "user", content: userContent }],
        },
        { signal },
      );
      let acc = "";
      for await (const event of stream) {
        if (event.type === "content_block_delta" && event.delta.type === "text_delta") {
          acc += event.delta.text;
          onToken(event.delta.text);
        }
      }
      const trimmed = acc.trim();
      return trimmed.length > 0 ? trimmed : null;
    }
    if (provider === "openai" && openaiClient) {
      const stream = await openaiClient.chat.completions.create(
        {
          model: OPENAI_MODEL,
          max_completion_tokens: maxTokens,
          stream: true,
          messages: [
            { role: "system", content: SYSTEM_PROMPT },
            { role: "user", content: userContent },
          ],
        },
        { signal },
      );
      let acc = "";
      for await (const chunk of stream) {
        const delta = chunk.choices[0]?.delta?.content ?? "";
        if (delta) {
          acc += delta;
          onToken(delta);
        }
      }
      const trimmed = acc.trim();
      return trimmed.length > 0 ? trimmed : null;
    }
    return null;
  } catch (err) {
    logger.warn({ err, provider }, "coach LLM stream failed; using template fallback");
    return null;
  } finally {
    done();
  }
}

// Streaming counterpart of narrate(). When the LLM is unavailable it emits the
// deterministic template in one shot (no streaming) and returns source:template.
// On the LLM path it streams tokens live and enforces the same disclaimer
// invariant as narrate(). If the stream errors before producing any text, it
// degrades to the template; if it errors mid-stream, it finalizes whatever was
// already emitted (so the frontend never double-renders).
async function narrateStream(
  userPrompt: string,
  data: unknown,
  fallback: string,
  onToken: TokenSink,
  cacheKey?: string,
): Promise<Narration> {
  if (!llmAvailable()) {
    const fb = enforceDisclaimer(fallback);
    onToken(fb);
    return { text: fb, source: "template" };
  }
  // Cache hit: emit the finished narration as a single chunk (no LLM call).
  if (cacheKey) {
    const cached = cacheGet(cacheKey);
    if (cached) {
      onToken(cached);
      return { text: cached, source: "llm" };
    }
    // Single-flight: a concurrent identical ask is already streaming. Wait for
    // its result and emit it in one chunk rather than firing a second LLM call.
    const existing = inflight.get(cacheKey);
    if (existing) {
      const text = await existing;
      if (text) {
        onToken(text);
        return { text, source: "llm" };
      }
      const fb = enforceDisclaimer(fallback);
      onToken(fb);
      return { text: fb, source: "template" };
    }
  }
  const content = `${userPrompt}\n\nDATA (authoritative — use these exact numbers, do not invent others):\n${JSON.stringify(data)}`;
  let streamed = "";
  // The leader streams tokens live to its own client and resolves the shared
  // promise with the final (disclaimer-enforced) text for any followers.
  const leader = (async (): Promise<string | null> => {
    const text = await completeStream(content, 900, (t) => {
      streamed += t;
      onToken(t);
    });
    if (!text) return null;
    const withDisclaimer = enforceDisclaimer(text);
    if (cacheKey) cacheSet(cacheKey, withDisclaimer);
    return withDisclaimer;
  })();
  if (cacheKey) {
    inflight.set(cacheKey, leader);
    void leader.finally(() => inflight.delete(cacheKey));
  }
  const text = await leader;
  if (!text) {
    if (streamed.length === 0) {
      const fb = enforceDisclaimer(fallback);
      onToken(fb);
      return { text: fb, source: "template" };
    }
    const partial = enforceDisclaimer(streamed);
    return { text: partial.trim(), source: "llm" };
  }
  return { text, source: "llm" };
}

const money = (n: number) => `$${Math.round(n).toLocaleString()}`;

// Models sometimes wrap JSON in ```json fences or surrounding prose. Pull out
// the first balanced {...} object so JSON.parse has a clean target.
function extractJsonObject(raw: string): string | null {
  const start = raw.indexOf("{");
  const end = raw.lastIndexOf("}");
  if (start === -1 || end === -1 || end <= start) return null;
  return raw.slice(start, end + 1);
}

// ─── Trade explanation ───────────────────────────────────────────────────────

function tradeTemplate(e: TradeExplanation): string {
  const lines = [
    `${e.symbol} ${e.strategyLabel} — ${e.daysToExpiry} DTE (${e.symbolName} near ${money(e.underlyingPrice)})`,
    "",
    `This is a ${e.isCredit ? `credit structure collecting ${money(e.credit)}` : `net-debit structure paying ${money(Math.abs(e.credit))}`} with defined risk. ${e.profitZone}`,
    "",
    "What the numbers mean:",
    ...e.keyPoints.map((k) => `• ${k}`),
    "",
    `Volatility & assignment: ${e.greeksPlain.vega} ${e.assignmentRisk}`,
    "",
    e.rejected
      ? `Note: the scanner flagged this candidate — ${e.rejectReason}.`
      : `This candidate currently clears the scanner's quality filters.`,
    "",
    e.disclaimer,
  ];
  return lines.join("\n");
}

const TRADE_PROMPT = `Explain this options trade to a learner so they understand exactly what it is, how it makes or loses money, what the Greeks imply, the probability of profit, the maximum loss, and the assignment risk. Walk through why the Ravish Score is what it is. Do NOT recommend taking or skipping it — only explain.`;

// Trade explanations are deterministic per symbol+strategy (the underlying quote
// is canonical), so concurrent asks for the same candidate can share one call.
const tradeCacheKey = (e: TradeExplanation) => `trade:${e.symbol}:${e.strategy}`;

export async function narrateTradeExplanation(
  e: TradeExplanation,
  level?: CoachLevel,
): Promise<Narration> {
  return narrate(
    TRADE_PROMPT + levelInstruction(level),
    e,
    tradeTemplate(e),
    tradeCacheKey(e) + levelKey(level),
  );
}

export async function narrateTradeExplanationStream(
  e: TradeExplanation,
  onToken: TokenSink,
  level?: CoachLevel,
): Promise<Narration> {
  return narrateStream(
    TRADE_PROMPT + levelInstruction(level),
    e,
    tradeTemplate(e),
    onToken,
    tradeCacheKey(e) + levelKey(level),
  );
}

// ─── Trade adjustment (Task #20) ─────────────────────────────────────────────

// The recommended action and every number are decided deterministically in
// lib/adjustment.ts. This narration ONLY explains WHY — it must never change the
// action or invent figures. Routed through narrate()/narrateStream() so the
// disclaimer invariant holds.
export interface AdjustmentNarrationInput {
  symbol: string;
  symbolName: string;
  strategyLabel: string;
  action: string;
  actionLabel: string;
  severity: string;
  rationale: string;
  triggeredSignals: string[];
  currentPop: number;
  entryPop: number;
  daysToExpiry: number;
  currentPnl: number;
  maxLoss: number;
  maxProfit: number;
  threatenedSide: string | null;
  nearestShortStrike: number | null;
  distanceToShortPct: number | null;
  assignmentRisk: string;
  disclaimer: string;
}

function adjustmentTemplate(a: AdjustmentNarrationInput): string {
  const why =
    a.triggeredSignals.length > 0
      ? a.triggeredSignals.map((s) => `• ${s}`)
      : ["• No adjustment thresholds breached — the position is inside tolerance."];
  return [
    `${a.symbol} ${a.strategyLabel} — recommended action: ${a.actionLabel}`,
    "",
    a.rationale,
    "",
    "Why now:",
    ...why,
    "",
    `Position health: POP ${a.currentPop}% (entry ${a.entryPop}%), ${a.daysToExpiry} DTE, open P&L ${money(a.currentPnl)} against ${money(a.maxLoss)} max loss.`,
    "",
    `Assignment: ${a.assignmentRisk}`,
    "",
    a.disclaimer,
  ].join("\n");
}

const ADJUSTMENT_PROMPT = `You are coaching a premium seller on an OPEN options position. The recommended action and all numbers below are already decided and authoritative. Explain WHY this is the right call: what the triggered signals mean, how they affect probability of profit and defined risk, and what the action accomplishes. Do NOT change the recommended action and do NOT invent numbers. If the action is "hold" or "do_nothing", explain why no change is warranted.`;

// Adjustments depend on live signals, so key the cache on the chosen action and
// the exact set of triggered signals (deterministic for a given trade/day).
const adjustmentCacheKey = (a: AdjustmentNarrationInput) =>
  `adjust:${a.symbol}:${a.action}:${a.triggeredSignals.join("|")}`;

export async function narrateAdjustment(
  a: AdjustmentNarrationInput,
  level?: CoachLevel,
): Promise<Narration> {
  return narrate(
    ADJUSTMENT_PROMPT + levelInstruction(level),
    a,
    adjustmentTemplate(a),
    adjustmentCacheKey(a) + levelKey(level),
  );
}

export async function narrateAdjustmentStream(
  a: AdjustmentNarrationInput,
  onToken: TokenSink,
  level?: CoachLevel,
): Promise<Narration> {
  return narrateStream(
    ADJUSTMENT_PROMPT + levelInstruction(level),
    a,
    adjustmentTemplate(a),
    onToken,
    adjustmentCacheKey(a) + levelKey(level),
  );
}

// ─── Greek lessons ───────────────────────────────────────────────────────────

function greekTemplate(l: GreekLesson): string {
  return [
    l.title,
    "",
    l.definition,
    "",
    `For premium sellers: ${l.forPremiumSellers}`,
    "",
    `Live example: ${l.example}`,
    "",
    l.disclaimer,
  ].join("\n");
}

const greekPrompt = (l: GreekLesson) =>
  `Teach the option Greek "${l.greek}" to a motivated beginner. Define it, explain why it matters specifically for a premium seller, and ground it in the live example provided. Keep it tight and intuitive.`;

// Greek lessons are deterministic per greek+symbol, so concurrent "Teach Me"
// clicks for the same pair can share one call.
const greekCacheKey = (l: GreekLesson) => `greek:${l.greek}:${l.symbol}`;

export async function narrateGreekLesson(
  l: GreekLesson,
  level?: CoachLevel,
): Promise<Narration> {
  return narrate(
    greekPrompt(l) + levelInstruction(level),
    l,
    greekTemplate(l),
    greekCacheKey(l) + levelKey(level),
  );
}

export async function narrateGreekLessonStream(
  l: GreekLesson,
  onToken: TokenSink,
  level?: CoachLevel,
): Promise<Narration> {
  return narrateStream(
    greekPrompt(l) + levelInstruction(level),
    l,
    greekTemplate(l),
    onToken,
    greekCacheKey(l) + levelKey(level),
  );
}

// ─── Journal / closed-trade review ───────────────────────────────────────────

export interface JournalReviewData {
  symbol: string;
  strategy: string;
  strategyLabel: string;
  status: string;
  outcome: string;
  realizedPnl: number | null;
  credit: number;
  maxProfit: number;
  maxLoss: number;
  pop: number;
  ev: number;
  ravishScore: number;
  exitReason: string | null;
  heldDays: number | null;
}

function reviewTemplate(d: JournalReviewData): { review: string; lessonLearned: string } {
  const won = (d.realizedPnl ?? 0) >= 0;
  const review = [
    `${d.symbol} ${d.strategyLabel} — ${d.outcome}${d.realizedPnl != null ? ` (${d.realizedPnl >= 0 ? "+" : ""}${money(d.realizedPnl)})` : ""}.`,
    "",
    `Entered with a Ravish Score of ${d.ravishScore.toFixed(1)}, ${d.pop.toFixed(0)}% POP, ${d.ev >= 0 ? "+" : ""}${money(d.ev)} expected value, and ${money(d.maxLoss)} defined risk against ${money(d.maxProfit)} max profit.`,
    won
      ? `The thesis played out: premium decayed in your favor and the underlying stayed within the structure.${d.exitReason ? ` Exit reason: ${d.exitReason}.` : ""}`
      : `The trade went against the structure.${d.exitReason ? ` Exit reason: ${d.exitReason}.` : ""} With ${d.pop.toFixed(0)}% POP, occasional losers are expected — what matters is that the loss stayed inside the defined-risk cap.`,
    "",
    COACH_DISCLAIMER,
  ].join("\n");
  const lessonLearned = won
    ? `Positive-EV, high-POP ${d.strategyLabel.toLowerCase()} entries with disciplined exits compound over time. Repeat the process, not the outcome.`
    : `A losing ${d.strategyLabel.toLowerCase()} is part of a ${d.pop.toFixed(0)}%-POP edge — the defined-risk cap (${money(d.maxLoss)}) did its job. Focus on consistent sizing and exits, not avoiding every loss.`;
  return { review, lessonLearned };
}

export interface JournalReview {
  review: string;
  lessonLearned: string;
  source: NarrationSource;
}

export async function narrateJournalReview(d: JournalReviewData): Promise<JournalReview> {
  const tpl = reviewTemplate(d);
  if (!llmAvailable()) return { ...tpl, source: "template" };
  const content = `Review this CLOSED options trade like a coach doing a post-mortem. Reply as strict JSON with two string fields: "review" (2-4 sentence coaching review of how the trade went and what the process teaches) and "lessonLearned" (one concise, durable takeaway). Do NOT recommend future trades.\n\nDATA:\n${JSON.stringify(d)}`;
  const raw = await complete(content, 700, { json: true });
  if (!raw) return { ...tpl, source: "template" };
  try {
    const json = extractJsonObject(raw);
    if (!json) return { ...tpl, source: "template" };
    const parsed = JSON.parse(json) as { review?: string; lessonLearned?: string };
    return {
      review: (parsed.review?.trim() || tpl.review) + `\n\n${COACH_DISCLAIMER}`,
      lessonLearned: parsed.lessonLearned?.trim() || tpl.lessonLearned,
      source: "llm",
    };
  } catch (err) {
    logger.warn({ err }, "coach journal review JSON parse failed; using template fallback");
    return { ...tpl, source: "template" };
  }
}

// Streaming counterpart of narrateJournalReview. Streams the prose review live
// (the slow, narration-heavy part) and pairs it with the deterministic template
// lessonLearned — single-token JSON streaming would be unreadable, so the
// durable takeaway stays deterministic while the review prose streams.
export async function narrateJournalReviewStream(
  d: JournalReviewData,
  onToken: TokenSink,
): Promise<JournalReview> {
  const tpl = reviewTemplate(d);
  const prompt = `Review this CLOSED options trade like a coach doing a post-mortem. Write a 2-4 sentence coaching review of how the trade went and what the process teaches. Do NOT recommend future trades and do NOT append a separate lesson summary — only the review prose.`;
  const n = await narrateStream(prompt, d, tpl.review, onToken);
  return { review: n.text, lessonLearned: tpl.lessonLearned, source: n.source };
}

// ─── Free-form teaching answer (used by the assistant in coach mode) ──────────

export async function narrateFreeform(question: string, context: unknown, fallback: string): Promise<Narration> {
  const prompt = `Answer this options-education question for a learner. ${question}`;
  return narrate(prompt, context ?? {}, fallback);
}
