import { pgTable, serial, text, real, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const settingsTable = pgTable("settings", {
  id: serial("id").primaryKey(),
  executionMode: text("execution_mode").notNull().default("manual"),
  maxRiskPerTrade: real("max_risk_per_trade").notNull().default(1.0),
  maxPortfolioRisk: real("max_portfolio_risk").notNull().default(10.0),
  profitTarget50: real("profit_target_50").notNull().default(50.0),
  profitTarget75: real("profit_target_75").notNull().default(75.0),
  profitTarget90: real("profit_target_90").notNull().default(90.0),
  stopLossMultiplier: real("stop_loss_multiplier").notNull().default(2.0),
  alpacaConnected: boolean("alpaca_connected").notNull().default(false),
  alpacaApiKey: text("alpaca_api_key"),
  scannerMode: text("scanner_mode").notNull().default("mock"),
  marketDataProvider: text("market_data_provider").notNull().default("mock"),
  defaultDte: integer("default_dte").notNull().default(45),
  shortDelta: real("short_delta").notNull().default(0.20),
  minIvRank: real("min_iv_rank").notNull().default(30.0),
  // Phase 6 — Full-Auto guardrails. The master switch (autoExecuteEnabled) is the
  // kill switch: even in full_auto mode nothing auto-submits unless it is armed.
  autoExecuteEnabled: boolean("auto_execute_enabled").notNull().default(false),
  autoMaxTradesPerDay: integer("auto_max_trades_per_day").notNull().default(5),
  autoMaxConcurrentPositions: integer("auto_max_concurrent_positions").notNull().default(10),
  autoMinRavishScore: real("auto_min_ravish_score").notNull().default(68.0),
  autoMaxDailyLossPct: real("auto_max_daily_loss_pct").notNull().default(5.0),
  autoQuantityPerTrade: integer("auto_quantity_per_trade").notNull().default(1),
  // Task #20 — Trade Adjustment Engine triggers. All have defaults so existing
  // settings rows keep working without a manual backfill.
  adjDeltaDriftTrigger: real("adj_delta_drift_trigger").notNull().default(0.30),
  adjPopDropTrigger: real("adj_pop_drop_trigger").notNull().default(15.0),
  adjShortStrikeProximityPct: real("adj_short_strike_proximity_pct").notNull().default(2.0),
  adjIvExpansionTrigger: real("adj_iv_expansion_trigger").notNull().default(25.0),
  adjDteTrigger: integer("adj_dte_trigger").notNull().default(21),
  // Master switch for the auto-adjustment loop (separate from autoExecuteEnabled,
  // which arms opening trades). Auto-adjust only ever closes / de-risks positions.
  autoAdjustEnabled: boolean("auto_adjust_enabled").notNull().default(false),
  // Event Risk Filter (earnings / FOMC / CPI / jobs / dividends / major events).
  // All default-on and additive for backward compat.
  eventRiskEnabled: boolean("event_risk_enabled").notNull().default(true),
  eventRiskBlockEarningsShortPremium: boolean("event_risk_block_earnings_short_premium").notNull().default(true),
  eventRiskAutoBlockHigh: boolean("event_risk_auto_block_high").notNull().default(true),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertSettingsSchema = createInsertSchema(settingsTable).omit({ id: true, updatedAt: true });
export type InsertSettings = z.infer<typeof insertSettingsSchema>;
export type Settings = typeof settingsTable.$inferSelect;
