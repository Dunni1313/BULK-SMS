# Ravish AI Options Trading Engine

An institutional-grade options trading platform built on Ravish's probability-based premium selling framework. Scans, ranks, backtests, and executes Iron Condors, Iron Flys, and Calendar Spreads across 10 major symbols (SPY, QQQ, IWM, NVDA, META, AAPL, AMZN, MSFT, GOOGL, TSLA).

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 8080)
- `pnpm --filter @workspace/ravish-trading run dev` — run the frontend (port 21294)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Frontend: React + Vite + Tailwind + shadcn/ui + Recharts
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `lib/api-spec/openapi.yaml` — OpenAPI contract (source of truth)
- `lib/db/src/schema/` — Drizzle tables: scannerResults, trades, backtestResults, journalEntries, aiMessages, settings
- `artifacts/api-server/src/routes/` — Express route handlers (scanner, options, portfolio, trades, backtest, scoring, journal, ai, settings, performance, execution)
- `artifacts/api-server/src/lib/execution.ts` — pre-trade risk validation, OCC symbol + multi-leg Alpaca order builder, preview/submit (mode-gated)
- `artifacts/api-server/src/lib/performanceAnalytics.ts` — deterministic seeded analytics engine (synthetic closed-trade population, NOT the live trades table); computes 17 metrics + 5-dimension breakdowns + equity curve
- `artifacts/ravish-trading/src/` — React frontend with Bloomberg-dark UI

## Architecture decisions

- All market data (option chains, portfolio, universe) is simulated with realistic math — wire up Alpaca API keys in Settings to connect real data
- The scanner generates Ravish Scores using the weighted formula: 30% POP + 25% EV + 15% Theta + 15% Win Rate + 10% Liquidity + 5% IV Rank
- AI Trading Coach (Phase 7): a read-only HYBRID teaching layer — deterministic math (`lib/coach.ts`) is always exact, an LLM (`lib/coachLLM.ts`) only narrates prose. The coach NEVER executes trades. Every narration is forced to carry the `COACH_DISCLAIMER` (enforced deterministically in `narrate()` even on the LLM path), and structured responses always include max loss + Greeks + assignment risk. Endpoints under `/coach/*`: explain-trade, teach-greek, quiz (generate+grade, server-authoritative quizId), journal-review (closed trades only), lessons, learn/delta, learn/greeks. Quiz grading decodes correctIndex from the base64url quizId — the bank is not exposed to clients
- The AI Assistant (`routes/ai.ts`) auto-detects teaching intent and routes into coach narration (explain/teach) while keeping all existing keyword data handlers. Coach narrations return `n.text` which already carries the disclaimer
- `OPENAI_API_KEY` may actually hold an Anthropic key (`sk-ant-` prefix). `coachLLM.ts` is provider-agnostic: it detects the prefix and uses `@anthropic-ai/sdk` or the OpenAI SDK accordingly. Default Anthropic model is `claude-haiku-4-5-20251001` (the `claude-3-5-haiku-latest` alias 404s on this account). Any LLM error degrades to a deterministic template (`source: "template"`) and never crashes the request
- Settings row is auto-created on first load (singleton pattern)
- Equity curves and backtest results are persisted to PostgreSQL
- Semi-automatic execution: `POST /execution/preview` (risk-validated ticket) and `POST /execution/submit` (mode-gated). Submit allowed in `semi_auto` and `full_auto` modes with explicit `confirm:true`; `manual` is scanner-only. It never bypasses risk checks. Reuses the existing Alpaca paper connection when creds are present, otherwise generates a mock order id. On submit it persists a pending trade (with `alpacaOrderId`) and a journal entry. Both semi-auto and full-auto route through the shared `executeValidatedTicket(ticket, source)` helper in execution.ts
- Full-Auto execution (Phase 6): a 60s scheduler (`startAutoScheduler` in index.ts) calls `runAutoExecutionCycle()`. It is a no-op unless mode=`full_auto` AND the master switch `autoExecuteEnabled` is on (the kill switch). Each cycle scans ranked scanner candidates, runs the same Phase 5 `buildTicket` validation, and auto-submits qualifying trades bounded by guardrails (per-day cap, concurrent cap, auto-only min score, daily-loss circuit breaker). PAPER/MOCK only. Endpoints: `GET /execution/auto/status`, `GET /execution/auto/log`, `POST /execution/auto/run` (manual trigger). Cycles are single-flighted and re-check guardrails before every execution — see Gotchas. Every decision (executed/skipped/rejected/blocked) is written to the `autoExecutionLog` table
- The execution score floor `MIN_RAVISH_SCORE` (62, the high_conviction tier boundary) is coupled to the scanner's score scale — see Gotchas
- Coach LLM streaming (Phase 8): the coach narration endpoints stream prose word-by-word over Server-Sent Events. `coachLLM.ts` exposes `completeStream()` (provider-agnostic — Anthropic `messages.stream()` `content_block_delta`, OpenAI `chat.completions` `stream:true`) and `narrateStream()`, which streams tokens on the LLM path and emits the deterministic template as a single chunk when the LLM is unavailable (`source: "template"`). SSE routes: `POST /coach/explain-trade/stream`, `/coach/teach-greek/stream`, `/coach/journal-review/stream`, and `/ai/chat/stream`. Each sends a `meta` event (deterministic context), `delta` events (text chunks), then a `done` event (authoritative final payload — the frontend replaces the streamed text with this on completion). Validation/lookup failures are returned as plain JSON with the proper status BEFORE the SSE stream opens. The SSE helper is `artifacts/api-server/src/lib/sse.ts` (`openSse`); the frontend client is `artifacts/ravish-trading/src/lib/coach-stream.ts` (`streamCoach`). The disclaimer invariant from `narrate()` is preserved in `narrateStream()` (enforced on the final text and on mid-stream-error partials). The streaming endpoints are deliberately NOT in the OpenAPI/orval contract — orval only models single-shot JSON — so the non-streaming JSON endpoints remain the contract and the stream client hand-rolls fetch + SSE parsing

- Event Risk Filter: a deterministic, simulated economic/market event calendar (`lib/eventRisk.ts`, modeled like `earnings.ts`) consulted by scanner scoring, the execution gate, and AutoPilot. `assessEventRisk()` is pure (seeded RNG + date math); `getEventRiskForSymbol()` pulls earnings from the snapshot; `getUpcomingEvents()` powers `GET /events`. It enforces four rules: (1) NO short premium (iron_condor/iron_fly) opened with earnings in the window — a hard server-side `blockShortPremium` violation in `validatePreTrade` (the `earnings` strategy is exempt as it trades the event; `calendar_spread` warns only); (2) advisory `warnings[]` when expiration crosses earnings/high-impact events (never blocks); (3) a score penalty subtracted from `score.total` then re-tiered via the new `scoreTier()` export; (4) AutoPilot skips candidates whose window carries high event risk. All gated by three settings toggles: `eventRiskEnabled` (master), `eventRiskBlockEarningsShortPremium`, `eventRiskAutoBlockHigh`. CRITICAL calibration: `blockAuto = (level === "high")`, and "high" requires a genuinely exceptional event (earnings we're not trading, or an FOMC) or `penalty >= MAX_PENALTY` — NOT routine monthly medium macro (CPI/jobs/PCE), which recurs in nearly every 30–45 DTE window and would otherwise block AutoPilot almost always. Frontend: `EventRiskBadge` on Scanner + Dashboard, warnings on the Trade Ticket validation card, a new `/events` Economic Calendar page, and the three Settings toggles. See `.agents/memory/event-risk-filter.md`
- Trade Adjustment Engine (Phase 9): a read-only-by-default open-position manager that mirrors the Full-Auto opening engine. The deterministic core is `lib/adjustment.ts` (`evaluateTradeAdjustment` computes signals + numbers; `selectAdjustment` is a pure, unit-tested precedence ladder choosing ONE action). The LLM only narrates WHY via `coachLLM.narrateAdjustment(+Stream)`, routed through `narrate()` so the disclaimer invariant holds. Source-of-truth numbers (maxLoss, Greeks, currentPop, assignment risk) are always deterministic. Short-strike threat detection uses a SIGNED directional gap (negative = breached/ITM), never absolute distance — a breach always triggers the proximity signal and escalates assignment risk (see Gotchas). Auto-adjustment (`lib/autoAdjustment.ts`) reuses the autoExecution safety model: single-flight cycle flag + per-action live re-check of `full_auto && autoExecuteEnabled (master kill switch) && autoAdjustEnabled`, and only `close_for_profit`/`close_for_loss`/`reduce_risk` are auto-actioned (never roll/convert). The AutoPilot master kill switch (`autoExecuteEnabled`) governs ALL automation — auto-adjust is a subordinate switch beneath it. Closes go through the shared `lib/tradeClose.ts` helper (also used by `DELETE /trades/:id`). Endpoints: `GET /trades/adjustments` (all open), `GET /trades/{id}/adjustment`, SSE `POST /trades/{id}/adjustment/stream`, and `POST /execution/auto/adjust/run`; the scheduler tick runs `runAutoAdjustmentCycle()` after `runAutoExecutionCycle()`. `trades.entryIv` is snapshotted at creation (both `POST /trades` and `executeValidatedTicket`) so IV-expansion is measured vs entry, with an IV-rank proxy fallback when null

- Performance Analytics (Phase 10): the live `trades` table is too sparse (a few closed trades) for meaningful analytics, so `lib/performanceAnalytics.ts` is a deterministic seeded engine that generates a synthetic closed-trade population (~220 trades, 24mo, 4 strategies incl. `strangle` × 10 symbols, each carrying strategy/symbol/dates/dte/shortDelta/ivRank/capital/credit/theta/commission/slippage/expectedPop/won/netPnl) and computes everything from it — NOT from the trades table, and it never writes to it. Pure functions: `computeMetrics`, `computeBreakdown(dim)`, `buildEquityCurve`, `filterByPeriod`; memoized per process. Convention: rate fields (winRate, maxDrawdown, returnOnCapital, actual/expectedPop) are 0–1 fractions (UI formats as %); profitFactor = grossWin/grossLoss; expectancy = winRate·avgWin − (1−winRate)·avgLoss; equity drawdown is a ≤0 fraction. CRITICAL P&L realism: losses are modeled as a multiple of CREDIT collected (managed stops), capped at max loss (capital) — NOT a fraction of capital — which is what keeps PF realistic (~1.9). `strangle` and the delta/ivRank/commission/slippage breakdown dimensions do NOT exist in the DB schema; they only exist in the synthetic population. The page carries a "SIMULATED" badge so users never mistake it for live broker history. Endpoints: `GET /performance/analytics`, `GET /performance/equity-curve`, `GET /performance/breakdown?dimension=&period=` (400 on bad dimension). Trade close dates are anchored to `Date.now()` so period windows roll forward — deterministic per process, not reproducible across days; don't claim "fully reproducible"

## Product

- **Dashboard** — portfolio summary, top-ranked scanner hits, account P&L
- **Scanner** — daily scan of 10 symbols × 3 strategies with Ravish Score ranking and tier badges (Elite/High Conviction/Good/Ignore)
- **Option Chain** — live Greeks (delta, theta, vega, gamma, IV) for any symbol
- **Portfolio** — aggregate Greeks dashboard with delta-neutral status and AI recommendations
- **Trades** — trade log with P&L tracking, profit targets, and one-click close
- **Backtest** — run 1/2/5-year backtests with equity curve visualization
- **Scoring Leaderboard** — AI-ranked top opportunities across all symbols
- **Journal** — trade journal with mood tags and lessons learned
- **AI Assistant** — natural language interface for portfolio queries
- **Trade Ticket** (`/ticket/:scannerId`) — review-and-submit page reached via "Review Trade" buttons on the Dashboard and Scanner; shows scaled legs, metrics, the full pre-trade risk validation, and a mode-gated Submit
- **AutoPilot** (`/autopilot`) — Full-Auto control center: master kill switch + mode toggle, guardrail editor, today's stats (trades/concurrent/slots/P&L vs loss limit), a "Run cycle now" trigger, and the live decision audit log
- **Trade Adjustment** — each open trade gets ONE deterministic recommendation (hold / close_for_profit / close_for_loss / roll_threatened / roll_untested / convert / reduce_risk / do_nothing) from a precedence ladder over monitored signals (delta drift, short-strike proximity/breach, POP drop, loss ≥ stop, profit target, IV expansion, DTE). The "Recommendation" column on the Trades page opens a sheet with the deterministic action + metrics and a streamed AI WHY. Advisory-only by default; auto de-risk (close/reduce) runs only under Full-Auto + the auto-adjust switch (PAPER/MOCK)
- **Event Calendar** (`/events`) — forward-looking economic/market event calendar (earnings, FOMC, CPI, jobs, dividends) grouped by date with impact badges and summary stats
- **Performance** (`/performance`) — simulated-trade analytics dashboard (carries a "SIMULATED" badge): 17 KPIs (win rate, profit factor, expectancy, ROC, max drawdown, Sharpe, Sortino, avg win/loss, avg hold days, theta, total P&L), equity curve + underwater-drawdown strip, best/worst strategy & ticker, actual-vs-expected POP, cost-impact (commission/slippage/drag), monthly returns, and a dimension-selectable breakdown (Strategy / Ticker / Duration / Delta / IV Rank) with bar chart + stats table. Period selector (3M/6M/1Y/All)
- **Settings** — execution mode (Manual/Semi-Auto/Full-Auto), risk limits, Alpaca connection, Event Risk Filter toggles

## User preferences

_Populate as you build._

## Gotchas

- Always run `pnpm --filter @workspace/api-spec run codegen` after changing `openapi.yaml`
- Query params + path params on the same operation can cause Orval TS2308 collisions — avoid by removing query params from mixed-param operations
- The `settings` table uses a singleton pattern — always fetch/update the first row
- Scanner `POST /scanner/run` deletes all existing results and regenerates — safe for demo seeding
- `MIN_RAVISH_SCORE` (execution.ts) is coupled to the scanner's score scale (optionsMath.ts tiers: elite ≥68, high_conviction ≥62). Set it above the achievable range and every preview/submit rejects on score — making execution dead. If you retune the score formula/tiers, re-check the floor and the Elite advisory in lockstep
- `GET /trades` does not expose the `alpacaOrderId` column in its response shape — query the DB directly to confirm the persisted order id
- Full-Auto safety invariants live in `lib/autoExecution.ts`: cycles are single-flighted (in-process `cycleInFlight` flag) so the scheduler tick and `POST /execution/auto/run` can't overlap and double-spend capacity, and guardrails are re-evaluated against live DB state before EVERY execution (not once per cycle) so the kill switch halts mid-cycle and caps can't drift. Don't "optimize" these back to a single pre-cycle snapshot. See `.agents/memory/auto-execution-engine.md`
- `autoMinRavishScore` (default 68, elite) is the auto-only floor, enforced as `max(autoMinRavishScore, MIN_RAVISH_SCORE)`. It is intentionally stricter than the semi-auto hard floor (62)
- Coach safety: the disclaimer (`COACH_DISCLAIMER`) is enforced in `coachLLM.ts` via `enforceDisclaimer()` on BOTH the LLM path AND every template/fallback return in `narrate()`/`narrateStream()` (appended unless already present), NOT in each caller. A feature-specific advisory like `ADJUSTMENT_DISCLAIMER` is NOT a substitute — it does not contain `COACH_DISCLAIMER`, so a template carrying only it would still get `COACH_DISCLAIMER` appended. If you add a new narration path, route it through `narrate()`/`narrateStream()` or you lose the disclaimer guarantee. Deterministic structured fields (maxLoss/Greeks/assignmentRisk) are the source of truth; LLM prose is commentary only and must never be the sole carrier of a number
- `TradeStrategy` and `ExplainTradeInputStrategy` share the same 4 values (`iron_condor`, `iron_fly`, `calendar_spread`, `earnings`) — use `calendar_spread`, never `calendar`. The trade-explanation-sheet `strategy` prop is typed as `ExplainTradeInput["strategy"]` to stay contract-aligned
- `POST /coach/journal-review` rejects non-closed trades with 400 — it is a closed-trade-only review endpoint
- Trade Adjustment short-strike threat detection MUST be a signed directional gap, NOT absolute distance. Use `callGap=(shortCall-price)/price`, `putGap=(price-shortPut)/price`; the threatened side is the smaller gap, `shortBreached = gap < 0`, and proximity triggers on `shortBreached || distancePct <= band`. If you revert to `Math.abs(price-strike)`, a deeply breached (ITM) short reads as "far away", fails the proximity trigger, and the engine recommends hold/roll instead of de-risking — and `buildAssignmentRisk` must take `breached` so a deep breach never reads "low". Covered by breached-call/breached-put tests in `phase8.adjustment.test.ts`
- Auto-adjustment auto-actions ONLY `close_for_profit`/`close_for_loss`/`reduce_risk` (`AUTO_ACTIONABLE`) — never roll/convert (structural, human-only). Same safety invariants as `autoExecution.ts`: single-flight + per-action live arm-gate re-check. The arm gate (`autoAdjustAllowed`) requires THREE switches: `full_auto` mode AND `autoExecuteEnabled` (the AutoPilot MASTER kill switch that governs all automation) AND `autoAdjustEnabled` (subordinate). The master kill switch is checked before the subordinate so disarming automation globally always halts auto-adjust. See `.agents/memory/trade-adjustment-engine.md`
- New `adj*` settings columns all have `.default()` for backward compat; `trades.entryIv` is nullable and tolerated as null (falls back to IV-rank proxy with threshold 70)

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
