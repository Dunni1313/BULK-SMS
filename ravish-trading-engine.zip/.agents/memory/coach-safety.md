---
name: AI Trading Coach safety invariants
description: The non-negotiable safety rules for the read-only coach/teaching layer.
---

# Coach safety invariants

The AI Trading Coach is a **read-only teaching layer**. It explains trades, tutors
Greeks, generates/grades quizzes, and reviews closed trades. It must NEVER execute,
submit, or place orders.

**Rules:**
- The coach disclaimer is enforced centrally in the LLM `narrate()` helper (appended
  unless already present), NOT in each caller. Any new narration path must route through
  `narrate()` or it loses the disclaimer guarantee.
- Deterministic structured fields (max loss, Greeks, assignment risk, POP) are the source
  of truth and are always rendered. LLM prose is commentary only — it must never be the
  sole carrier of a number.
- Quiz grading is server-authoritative: the quizId base64url-encodes the correct-answer
  indices; the question bank is never exposed to clients.
- `journal-review` is closed-trades-only (rejects non-closed with 400).

**Why:** the product contract guarantees every coach response carries max loss + Greeks +
assignment risk + disclaimer, and that the assistant can never be tricked into trading.
Centralizing the disclaimer + keeping math deterministic is what makes those guarantees
hold even when the LLM hallucinates or fails.

**How to apply:** when extending the coach, add deterministic computation first, treat the
LLM as an optional prose wrapper, and keep all execution/order code paths out of `coach.ts`
and `routes/coach.ts`.

## UI testing gotcha

The coach UI flows (Teach Me, Explain This Trade sheet) hit LLM-backed endpoints
(`/coach/teach-greek`, `/coach/explain-trade`) that take ~10-20s each. Running multiple
coach `runTest` flows in **parallel** saturates them and the proxy returns 502 / empty
renders — these are gateway timeouts, NOT safety regressions. Verify endpoints work via
curl, then re-run coach UI tests **sequentially** (or one flow per run) with generous waits.
Quiz/journal-review are lighter and tolerate parallelism better.
